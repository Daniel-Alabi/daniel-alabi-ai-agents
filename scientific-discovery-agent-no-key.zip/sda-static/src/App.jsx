import { useState } from 'react'
import { SearchStage } from './components/SearchStage'
import { HypothesizeStage } from './components/HypothesizeStage'
import { DesignStage } from './components/DesignStage'
import { ExportStage } from './components/ExportStage'
import { generateFullReport } from './templates'
import s from './App.module.css'

const STAGES = ['Search', 'Hypothesize', 'Design', 'Export']

export default function App() {
  const [stage, setStage] = useState(0)
  const [litData, setLitData] = useState(null)
  const [hypData, setHypData] = useState(null)
  const [designData, setDesignData] = useState(null)
  const [fullReport, setFullReport] = useState('')

  function handleExport() {
    const report = generateFullReport(
      litData,
      { topic: litData.topic, hypotheses: hypData },
      { ...designData?.data, topic: litData.topic, hypothesisRef: 'See Hypothesis Register', studyType: designData?.studyType }
    )
    setFullReport(report)
    setStage(3)
  }

  function restart() {
    setStage(0); setLitData(null); setHypData(null); setDesignData(null); setFullReport('')
  }

  const completed = [!!litData, !!hypData, !!designData, false]

  return (
    <div className={s.app}>
      <header className={s.header}>
        <div className={s.logo} aria-hidden="true">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0h10a2 2 0 0 0 2-2v-4M9 21H5a2 2 0 0 1-2-2v-4m0 0h18"/>
          </svg>
        </div>
        <div>
          <h1 className={s.title}>Scientific Discovery Agent</h1>
          <p className={s.subtitle}>Structured 3-stage pipeline · No API key required</p>
        </div>
      </header>

      <nav className={s.tabs} aria-label="Pipeline stages">
        {STAGES.map((label, i) => (
          <button
            key={label}
            className={`${s.tab} ${stage === i ? s.active : ''} ${completed[i] ? s.done : ''}`}
            onClick={() => { if (i <= stage || completed[i - 1]) setStage(i) }}
            disabled={i > stage && !completed[i - 1]}
            aria-current={stage === i ? 'step' : undefined}
          >
            <span className={s.badge}>{completed[i] ? '✓' : i + 1}</span>
            {label}
          </button>
        ))}
      </nav>

      <main className={s.main}>
        {stage === 0 && <SearchStage saved={litData} onSave={setLitData} onNext={() => setStage(1)} />}
        {stage === 1 && <HypothesizeStage topic={litData?.topic || ''} saved={hypData} onSave={setHypData} onNext={() => setStage(2)} onBack={() => setStage(0)} />}
        {stage === 2 && <DesignStage topic={litData?.topic || ''} hypothesisRef={hypData ? `${hypData.length} hypothesis(es) defined` : ''} saved={designData} onSave={setDesignData} onBack={() => setStage(1)} onExport={handleExport} />}
        {stage === 3 && <ExportStage report={fullReport} topic={litData?.topic || ''} onRestart={restart} />}
      </main>

      <footer className={s.footer}>
        No API key required · All data stays in your browser ·{' '}
        <a href="https://github.com" target="_blank" rel="noreferrer">View on GitHub</a>
      </footer>
    </div>
  )
}
