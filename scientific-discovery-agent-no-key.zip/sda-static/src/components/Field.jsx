import s from './Field.module.css'

export function Field({ label, hint, required, children }) {
  return (
    <div className={s.field}>
      <label className={s.label}>
        {label}
        {required && <span className={s.req}>*</span>}
      </label>
      {hint && <p className={s.hint}>{hint}</p>}
      {children}
    </div>
  )
}
