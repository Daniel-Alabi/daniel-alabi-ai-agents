import { useState, useEffect } from 'react'
import { Field } from './Field'
import { ChipGroup } from './ChipGroup'
import { Preview } from './Preview'
import { generateExperimentDesign, downloadText } from '../templates'
import s from './StageForm.module.css'

const STUDY_TYPES = ['In vitro','In vivo (animal)','Clinical trial','Computational','Observational','Meta-analysis','Mixed methods']
const ALPHA_OPTS = ['0.001','0.01','0.05','0.10']
const POWER_OPTS = ['0.70','0.80','0.90','0.95']
const INIT = { objective:'',population:'',sampleSize:'',sampleRationale:'',intervention:'',controls:'',measurements:'',primaryOutcome:'',secondaryOutcomes:'',statisticalTest:'',alpha:'0.05',power:'0.80',timeline:'',budget:'',ethicsBoard:'',informedConsent:'',risks:'',limitations:'',expectedOutcome:'' }

export function DesignStage({ topic, hypothesisRef, saved, onSave, onBack, onExport }) {
  const [studyType, setStudyType] = useState(saved?.studyType || 'In vitro')
  const [d, setD] = useState(saved?.data || INIT)
  const [preview, setPreview] = useState('')
  function set(k, v) { setD(prev => ({ ...prev, [k]: v })) }

  useEffect(() => {
    setPreview(generateExperimentDesign({ topic, hypothesisRef, studyType, ...d }))
  }, [d, studyType, topic, hypothesisRef])

  function handleExport() { onSave({ studyType, data: d }); onExport(preview) }
  const canExport = d.objective.trim() && d.population.trim()

  return (
    <div className={s.layout}>
      <div className={s.form}>
        <Field label="Study type">
          <ChipGroup options={STUDY_TYPES} value={studyType} onChange={setStudyType} />
        </Field>
        <Field label="Overall aim / objective" required hint="One sentence stating what this study will achieve.">
          <textarea rows={2} value={d.objective} onChange={e => set('objective', e.target.value)} placeholder="e.g. To determine whether 8-week probiotic supplementation reduces PHQ-9 scores in treatment-resistant depression patients." />
        </Field>

        <div className={s.sectionDivider}>Participants / Samples</div>
        <div className={s.twoCol}>
          <Field label="Population / material" required>
            <input value={d.population} onChange={e => set('population', e.target.value)} placeholder="e.g. Adults 18–65, diagnosis of MDD, failed ≥2 antidepressants" />
          </Field>
          <Field label="Sample size">
            <input value={d.sampleSize} onChange={e => set('sampleSize', e.target.value)} placeholder="e.g. n=120 (60 per arm)" />
          </Field>
        </div>
        <Field label="Sample size rationale" hint="Power calculation or justification.">
          <input value={d.sampleRationale} onChange={e => set('sampleRationale', e.target.value)} placeholder="e.g. 80% power to detect d=0.5 at α=0.05, accounting for 15% dropout" />
        </Field>

        <div className={s.sectionDivider}>Study Design</div>
        <Field label="Intervention / treatment">
          <textarea rows={2} value={d.intervention} onChange={e => set('intervention', e.target.value)} placeholder="e.g. Multi-strain probiotic (10^9 CFU/day) for 8 weeks, oral administration" />
        </Field>
        <Field label="Control group">
          <input value={d.controls} onChange={e => set('controls', e.target.value)} placeholder="e.g. Matched placebo capsule, double-blind RCT" />
        </Field>
        <Field label="Key measurements and methods">
          <textarea rows={3} value={d.measurements} onChange={e => set('measurements', e.target.value)} placeholder="e.g. PHQ-9 at baseline, 4 weeks, 8 weeks. 16S rRNA gut microbiome sequencing. Serum cytokine panel." />
        </Field>

        <div className={s.sectionDivider}>Outcomes</div>
        <div className={s.twoCol}>
          <Field label="Primary outcome">
            <input value={d.primaryOutcome} onChange={e => set('primaryOutcome', e.target.value)} placeholder="e.g. Change in PHQ-9 score at 8 weeks" />
          </Field>
          <Field label="Secondary outcomes">
            <input value={d.secondaryOutcomes} onChange={e => set('secondaryOutcomes', e.target.value)} placeholder="e.g. Microbiome diversity, serum IL-6, remission rate" />
          </Field>
        </div>

        <div className={s.sectionDivider}>Statistical Analysis</div>
        <Field label="Statistical test">
          <input value={d.statisticalTest} onChange={e => set('statisticalTest', e.target.value)} placeholder="e.g. Two-sided independent t-test, ANCOVA adjusting for baseline score" />
        </Field>
        <div className={s.twoCol}>
          <Field label="Significance level (α)"><ChipGroup options={ALPHA_OPTS} value={d.alpha} onChange={v => set('alpha', v)} /></Field>
          <Field label="Statistical power (1−β)"><ChipGroup options={POWER_OPTS} value={d.power} onChange={v => set('power', v)} /></Field>
        </div>

        <div className={s.sectionDivider}>Logistics (optional)</div>
        <div className={s.twoCol}>
          <Field label="Timeline">
            <textarea rows={3} value={d.timeline} onChange={e => set('timeline', e.target.value)} placeholder={"Month 1–2: Recruitment\nMonth 3–10: Intervention\nMonth 11–12: Analysis"} />
          </Field>
          <Field label="Budget estimate">
            <textarea rows={3} value={d.budget} onChange={e => set('budget', e.target.value)} placeholder={"Supplements: $5,000\nSequencing: $15,000\nStaff: $40,000\nTotal: ~$60,000"} />
          </Field>
        </div>

        <div className={s.sectionDivider}>Ethics</div>
        <Field label="Ethics / IRB board">
          <input value={d.ethicsBoard} onChange={e => set('ethicsBoard', e.target.value)} placeholder="e.g. University IRB approval required prior to recruitment" />
        </Field>
        <div className={s.twoCol}>
          <Field label="Informed consent">
            <input value={d.informedConsent} onChange={e => set('informedConsent', e.target.value)} placeholder="e.g. Written consent obtained from all participants" />
          </Field>
          <Field label="Key risks">
            <input value={d.risks} onChange={e => set('risks', e.target.value)} placeholder="e.g. GI discomfort; unblinding risk" />
          </Field>
        </div>

        <div className={s.sectionDivider}>Conclusions</div>
        <Field label="Limitations">
          <textarea rows={2} value={d.limitations} onChange={e => set('limitations', e.target.value)} placeholder="e.g. Self-reported outcomes; short follow-up; single-centre design" />
        </Field>
        <Field label="Expected outcomes and interpretation">
          <textarea rows={3} value={d.expectedOutcome} onChange={e => set('expectedOutcome', e.target.value)} placeholder="e.g. If H1 is supported, results will justify a larger multi-centre RCT..." />
        </Field>

        <div className={s.actions}>
          <button className={s.ghost} onClick={onBack}>← Back</button>
          <button className={s.primary} onClick={handleExport} disabled={!canExport}>Export full report ↓</button>
        </div>
      </div>

      <div className={s.preview}>
        <Preview text={preview} placeholder="Fill in objective and population to preview." onDownload={downloadText} filename={`experiment-design-${Date.now()}.txt`} />
      </div>
    </div>
  )
}
