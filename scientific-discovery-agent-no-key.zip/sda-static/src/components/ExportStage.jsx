import { Preview } from './Preview'
import { downloadText } from '../templates'
import s from './ExportStage.module.css'

export function ExportStage({ report, topic, onRestart }) {
  return (
    <div className={s.wrap}>
      <div className={s.hero}>
        <div className={s.check}>✓</div>
        <h2 className={s.heading}>Pipeline complete</h2>
        <p className={s.sub}>Your full scientific discovery report for <strong>{topic}</strong> is ready.</p>
        <div className={s.btnRow}>
          <button className={s.primary} onClick={() => downloadText(`discovery-report-${Date.now()}.txt`, report)}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
            Download full report (.txt)
          </button>
          <button className={s.ghost} onClick={onRestart}>Start new pipeline</button>
        </div>
      </div>
      <Preview text={report} onDownload={downloadText} filename={`discovery-report-${Date.now()}.txt`} />
    </div>
  )
}
