import { useState, useEffect } from 'react'
import { Field } from './Field'
import { ChipGroup } from './ChipGroup'
import { Preview } from './Preview'
import { generateLiteratureSummary, downloadText } from '../templates'
import s from './StageForm.module.css'

const DOMAINS = ['General','Biology','Chemistry','Physics','Medicine','Neuroscience','Materials','Ecology','CS / AI','Psychology','Environmental','Economics']
const DEPTHS = ['Broad overview','Focused review','Deep synthesis']
const INIT = { topic: '', domain: 'General', depth: 'Broad overview', priorWork: '', controversies: '', gaps: '', trends: '' }

export function SearchStage({ saved, onSave, onNext }) {
  const [d, setD] = useState(saved || INIT)
  const [preview, setPreview] = useState('')
  function set(k, v) { setD(prev => ({ ...prev, [k]: v })) }

  useEffect(() => {
    if (d.topic.trim()) setPreview(generateLiteratureSummary(d))
    else setPreview('')
  }, [d])

  function handleNext() { onSave(d); onNext() }
  const canProceed = d.topic.trim() && d.priorWork.trim()

  return (
    <div className={s.layout}>
      <div className={s.form}>
        <Field label="Research topic" required hint="State your research question or area of investigation.">
          <input value={d.topic} onChange={e => set('topic', e.target.value)} placeholder="e.g. Role of gut microbiome in treatment-resistant depression" />
        </Field>
        <Field label="Domain">
          <ChipGroup options={DOMAINS} value={d.domain} onChange={v => set('domain', v)} />
        </Field>
        <Field label="Evidence depth">
          <ChipGroup options={DEPTHS} value={d.depth} onChange={v => set('depth', v)} />
        </Field>
        <Field label="Current state of knowledge" required hint="Summarise 3–6 key findings from existing literature. Be specific about mechanisms and evidence quality.">
          <textarea rows={5} value={d.priorWork} onChange={e => set('priorWork', e.target.value)} placeholder="e.g. Multiple RCTs have demonstrated a correlation between gut dysbiosis markers and depression severity scores (PHQ-9). Animal models show vagal nerve involvement..." />
        </Field>
        <Field label="Key debates or contradictions" hint="What do researchers disagree about? What remains contested?">
          <textarea rows={3} value={d.controversies} onChange={e => set('controversies', e.target.value)} placeholder="e.g. Causality vs. correlation remains debated. Some meta-analyses report small effect sizes..." />
        </Field>
        <Field label="Critical gaps" hint="Where is evidence weakest? What questions remain unanswered?">
          <textarea rows={3} value={d.gaps} onChange={e => set('gaps', e.target.value)} placeholder="e.g. No longitudinal human trials. Mechanisms poorly understood..." />
        </Field>
        <Field label="Promising directions" hint="Where is the field headed?">
          <textarea rows={3} value={d.trends} onChange={e => set('trends', e.target.value)} placeholder="e.g. Psychobiotics, FMT studies, multi-omics integration..." />
        </Field>
        <div className={s.actions}>
          <button className={s.primary} onClick={handleNext} disabled={!canProceed}>Save &amp; continue →</button>
        </div>
      </div>
      <div className={s.preview}>
        <Preview text={preview} placeholder="Start typing your topic to preview the document." onDownload={downloadText} filename={`literature-summary-${Date.now()}.txt`} />
      </div>
    </div>
  )
}
