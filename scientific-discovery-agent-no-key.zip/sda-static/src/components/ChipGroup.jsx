import s from './ChipGroup.module.css'

export function ChipGroup({ options, value, onChange, multi = false }) {
  const selected = multi ? (Array.isArray(value) ? value : []) : value
  function toggle(opt) {
    if (multi) {
      onChange(selected.includes(opt) ? selected.filter(x => x !== opt) : [...selected, opt])
    } else {
      onChange(opt)
    }
  }
  return (
    <div className={s.group}>
      {options.map(opt => (
        <button
          key={opt}
          type="button"
          className={`${s.chip} ${(multi ? selected.includes(opt) : selected === opt) ? s.on : ''}`}
          onClick={() => toggle(opt)}
        >{opt}</button>
      ))}
    </div>
  )
}
