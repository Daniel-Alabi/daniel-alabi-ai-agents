import { useState, useEffect } from 'react'
import { Field } from './Field'
import { ChipGroup } from './ChipGroup'
import { Preview } from './Preview'
import { generateHypotheses, downloadText } from '../templates'
import s from './StageForm.module.css'

const FOCUS_TYPES = ['Mechanistic','Correlational','Interventional','Comparative','Predictive']
const NOVELTY_OPTS = ['1','2','3','4','5']
const BLANK_HYP = { focus: 'Mechanistic', statement: '', rationale: '', ifTrue: '', ifFalse: '', independent: '', dependent: '', confounders: '', novelty: '3', feasibility: '3' }

export function HypothesizeStage({ topic, saved, onSave, onNext, onBack }) {
  const [hypotheses, setHypotheses] = useState(saved || [{ ...BLANK_HYP }])
  const [preview, setPreview] = useState('')

  function setH(i, k, v) { setHypotheses(prev => prev.map((h, j) => j === i ? { ...h, [k]: v } : h)) }
  function addHyp() { setHypotheses(prev => [...prev, { ...BLANK_HYP }]) }
  function removeHyp(i) { setHypotheses(prev => prev.filter((_, j) => j !== i)) }

  useEffect(() => { setPreview(generateHypotheses({ topic, hypotheses })) }, [hypotheses, topic])

  function handleNext() { onSave(hypotheses); onNext() }
  const canProceed = hypotheses.every(h => h.statement.trim())

  return (
    <div className={s.layout}>
      <div className={s.form}>
        {hypotheses.map((h, i) => (
          <div key={i} className={s.hypBlock}>
            <div className={s.hypHeader}>
              <span className={s.hypNum}>Hypothesis {i + 1}</span>
              {hypotheses.length > 1 && <button className={s.removeBtn} onClick={() => removeHyp(i)} type="button">Remove</button>}
            </div>
            <Field label="Focus type">
              <ChipGroup options={FOCUS_TYPES} value={h.focus} onChange={v => setH(i, 'focus', v)} />
            </Field>
            <Field label="Hypothesis statement" required hint="State in clear if-then or mechanistic form.">
              <textarea rows={2} value={h.statement} onChange={e => setH(i, 'statement', e.target.value)} placeholder="e.g. If gut microbiome diversity is increased via probiotic supplementation, then depression severity scores will decrease in treatment-resistant patients." />
            </Field>
            <Field label="Mechanistic rationale" hint="Why should this be true based on the literature?">
              <textarea rows={2} value={h.rationale} onChange={e => setH(i, 'rationale', e.target.value)} placeholder="e.g. The gut-brain axis via vagal nerve and serotonin precursor production may mediate this effect..." />
            </Field>
            <div className={s.twoCol}>
              <Field label="If true, it means…">
                <input value={h.ifTrue} onChange={e => setH(i, 'ifTrue', e.target.value)} placeholder="Microbiome modulation is a viable target." />
              </Field>
              <Field label="If false, it means…">
                <input value={h.ifFalse} onChange={e => setH(i, 'ifFalse', e.target.value)} placeholder="The mechanism operates differently." />
              </Field>
            </div>
            <div className={s.threeCol}>
              <Field label="Independent variable">
                <input value={h.independent} onChange={e => setH(i, 'independent', e.target.value)} placeholder="Probiotic dosage" />
              </Field>
              <Field label="Dependent variable">
                <input value={h.dependent} onChange={e => setH(i, 'dependent', e.target.value)} placeholder="PHQ-9 score" />
              </Field>
              <Field label="Confounders">
                <input value={h.confounders} onChange={e => setH(i, 'confounders', e.target.value)} placeholder="Diet, medication use" />
              </Field>
            </div>
            <div className={s.twoCol}>
              <Field label="Novelty (1–5)"><ChipGroup options={NOVELTY_OPTS} value={h.novelty} onChange={v => setH(i, 'novelty', v)} /></Field>
              <Field label="Feasibility (1–5)"><ChipGroup options={NOVELTY_OPTS} value={h.feasibility} onChange={v => setH(i, 'feasibility', v)} /></Field>
            </div>
          </div>
        ))}
        {hypotheses.length < 5 && <button className={s.addBtn} onClick={addHyp} type="button">+ Add another hypothesis</button>}
        <div className={s.actions}>
          <button className={s.ghost} onClick={onBack}>← Back</button>
          <button className={s.primary} onClick={handleNext} disabled={!canProceed}>Save &amp; continue →</button>
        </div>
      </div>
      <div className={s.preview}>
        <Preview text={preview} placeholder="Fill in hypothesis statements to preview." onDownload={downloadText} filename={`hypotheses-${Date.now()}.txt`} />
      </div>
    </div>
  )
}
