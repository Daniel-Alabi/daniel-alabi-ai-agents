import s from './Preview.module.css'

export function Preview({ text, placeholder, onDownload, filename }) {
  if (!text) {
    return (
      <div className={`${s.box} ${s.empty}`}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M9 12h6M9 16h6M9 8h3M5 4h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z"/></svg>
        <p>{placeholder || 'Fill in the form to generate your document.'}</p>
      </div>
    )
  }
  return (
    <div className={s.box}>
      <div className={s.toolbar}>
        <span className={s.toolbarLabel}>Preview</span>
        {onDownload && (
          <button className={s.dlBtn} onClick={() => onDownload(filename, text)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
            Download .txt
          </button>
        )}
      </div>
      <pre className={s.pre}>{text}</pre>
    </div>
  )
}
