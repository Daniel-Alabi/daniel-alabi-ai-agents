// ─── Template Engine ──────────────────────────────────────────────────────────
// Generates structured scientific documents from user inputs.
// No API required — all logic runs in the browser.

export function generateLiteratureSummary(data) {
  const { topic, domain, priorWork, gaps, controversies, trends } = data
  const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long' })

  return `LITERATURE SUMMARY
Topic: ${topic}
Domain: ${domain}
Generated: ${date}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CURRENT STATE OF KNOWLEDGE

${priorWork || '[No prior work described]'}

KEY DEBATES AND CONTRADICTIONS

${controversies || '[No controversies described]'}

CRITICAL GAPS IN THE LITERATURE

${gaps || '[No gaps described]'}

PROMISING DIRECTIONS

${trends || '[No trends described]'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
This summary was compiled using the Scientific Discovery Agent.
`.trim()
}

export function generateHypotheses(data) {
  const { topic, hypotheses } = data
  const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long' })

  const hyps = hypotheses.map((h, i) => `HYPOTHESIS ${i + 1}: ${h.focus.toUpperCase()}
${'─'.repeat(50)}
Statement:      ${h.statement || '[Not specified]'}
Rationale:      ${h.rationale || '[Not specified]'}
If true:        ${h.ifTrue || '[Not specified]'}
If false:       ${h.ifFalse || '[Not specified]'}
Key variables:  Independent — ${h.independent || '[Not specified]'}
                Dependent   — ${h.dependent || '[Not specified]'}
                Confounders — ${h.confounders || '[None listed]'}
Novelty:        ${'★'.repeat(Number(h.novelty) || 3)}${'☆'.repeat(5 - (Number(h.novelty) || 3))} (${h.novelty || 3}/5)
Feasibility:    ${'★'.repeat(Number(h.feasibility) || 3)}${'☆'.repeat(5 - (Number(h.feasibility) || 3))} (${h.feasibility || 3}/5)
`.trim()).join('\n\n')

  return `HYPOTHESIS REGISTER
Topic: ${topic}
Generated: ${date}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${hyps}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
This register was compiled using the Scientific Discovery Agent.
`.trim()
}

export function generateExperimentDesign(data) {
  const {
    topic, hypothesisRef, studyType, objective,
    population, sampleSize, sampleRationale,
    intervention, controls, measurements,
    primaryOutcome, secondaryOutcomes,
    statisticalTest, alpha, power,
    timeline, budget,
    ethicsBoard, informedConsent, risks,
    limitations, expectedOutcome
  } = data
  const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long' })

  return `EXPERIMENT DESIGN PROTOCOL
Topic: ${topic}
Study type: ${studyType}
Hypothesis: ${hypothesisRef || '[See hypothesis register]'}
Generated: ${date}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

OVERALL AIM
${objective || '[Not specified]'}

PARTICIPANTS / SAMPLES / MATERIALS
Population:       ${population || '[Not specified]'}
Sample size:      ${sampleSize || '[Not specified]'}
Rationale:        ${sampleRationale || '[Not specified]'}

STUDY DESIGN
Type:             ${studyType}
Intervention:     ${intervention || '[Not specified]'}
Control group:    ${controls || '[Not specified]'}

KEY MEASUREMENTS
${measurements || '[Not specified]'}

OUTCOMES
Primary:          ${primaryOutcome || '[Not specified]'}
Secondary:        ${secondaryOutcomes || '[Not specified]'}

STATISTICAL ANALYSIS PLAN
Test:             ${statisticalTest || '[Not specified]'}
Significance (α): ${alpha || '0.05'}
Power (1−β):      ${power || '0.80'}

${timeline ? `TIMELINE\n${timeline}\n` : ''}
${budget ? `BUDGET ESTIMATE\n${budget}\n` : ''}
ETHICAL CONSIDERATIONS
Ethics board:     ${ethicsBoard || '[Not specified]'}
Informed consent: ${informedConsent || '[Not specified]'}
Risks:            ${risks || '[Not specified]'}

LIMITATIONS
${limitations || '[Not specified]'}

EXPECTED OUTCOMES AND INTERPRETATION
${expectedOutcome || '[Not specified]'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
This protocol was compiled using the Scientific Discovery Agent.
`.trim()
}

export function generateFullReport(litData, hypData, designData) {
  const lit = generateLiteratureSummary(litData)
  const hyp = generateHypotheses(hypData)
  const design = generateExperimentDesign(designData)
  const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })

  return `SCIENTIFIC DISCOVERY PIPELINE — FULL REPORT
Topic: ${litData.topic}
Date: ${date}
${'═'.repeat(50)}

${lit}

${'═'.repeat(50)}

${hyp}

${'═'.repeat(50)}

${design}
`
}

export function downloadText(filename, content) {
  const blob = new Blob([content], { type: 'text/plain' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}
