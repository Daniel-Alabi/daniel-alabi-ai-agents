# Scientific Discovery Agent

A structured 3-stage scientific discovery pipeline. **No API key, no backend, no cost** — runs entirely in the browser.

## What it does

Guides researchers through a structured pipeline:

1. **Search** — Document your literature review: current knowledge, debates, gaps, promising directions
2. **Hypothesize** — Define up to 5 testable hypotheses with variables, rationale, novelty and feasibility ratings
3. **Design** — Build a full experiment protocol: participants, intervention, controls, statistical plan, ethics, budget, timeline
4. **Export** — Download a complete formatted `.txt` report

Live preview updates as you type at every stage.

## Tech stack

- React 18 + Vite
- CSS Modules
- Zero runtime dependencies beyond React
- No API key, no environment variables

## Getting started

```bash
git clone https://github.com/YOUR_USERNAME/scientific-discovery-agent.git
cd scientific-discovery-agent
npm install
npm run dev
```

Opens at http://localhost:3000

## Build

```bash
npm run build     # outputs to /dist
npm run preview   # preview production build
```

## Deploy

### Netlify

1. Push to GitHub
2. Connect repo in [Netlify](https://netlify.com)
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Deploy — no environment variables needed

### Vercel

1. Push to GitHub
2. Import in [Vercel](https://vercel.com)
3. Framework: Vite
4. Deploy — no environment variables needed

### Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit: Scientific Discovery Agent"
git remote add origin https://github.com/YOUR_USERNAME/scientific-discovery-agent.git
git branch -M main
git push -u origin main
```

## Project structure

```
src/
├── components/
│   ├── SearchStage.jsx        # Stage 1: Literature summary form
│   ├── HypothesizeStage.jsx   # Stage 2: Hypothesis builder
│   ├── DesignStage.jsx        # Stage 3: Experiment protocol form
│   ├── ExportStage.jsx        # Stage 4: Download & review
│   ├── Field.jsx              # Labelled form field wrapper
│   ├── ChipGroup.jsx          # Single/multi-select chip control
│   └── Preview.jsx            # Live document preview pane
├── templates.js               # Document generation logic
├── App.jsx                    # Root component + stage routing
└── index.css                  # Global styles + CSS variables
```

## License

MIT
