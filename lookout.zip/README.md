# Lookout — a vision-language agent over camera feeds

A full-stack teaching project. The central fact it's built around: Claude's API accepts
images, not video. Every "video agent" is therefore an architecture problem — how you
convert a continuous feed into discrete perception, persistent memory, and grounded
reasoning. Lookout makes each of those decisions a visible, labeled component. The
panel eyebrows in the UI ("PATTERN 04 · ...") map directly to the sections below.

## Quick start

```bash
cd lookout
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...        # required
export LOOKOUT_MODEL=claude-sonnet-4-20250514   # optional override
uvicorn backend.main:app --reload
```

Open http://127.0.0.1:8000, allow the webcam (or load a video file), and click
"start watching". Webcam access requires localhost or HTTPS — localhost is fine.

## The six patterns

### Pattern 01 — Frame sampling (frontend/index.html, `captureFrame`)

The browser draws the `<video>` element onto a canvas, downscaled to ≤768px wide and
encoded as JPEG at quality 0.72, then ships base64 to the backend. This keeps each
frame around 50–120 KB, which matters because image tokens dominate your cost. The
same capture path serves the webcam, an uploaded video file, and the chat tool —
one perception interface, three sources.

### Pattern 02 — Structured perception (backend/agent.py, `perceive`)

Each frame goes to the model with a system prompt demanding strict JSON: summary,
entities, changes, an activity score 0–10, and discrete events. Free-prose
descriptions are useless to a program; a fixed schema turns the VLM into a sensor
with a typed output. `_parse_json_block` is deliberately tolerant (strips fences,
finds the outermost object) because models occasionally decorate their JSON.

### Pattern 03 — Differential perception + rolling memory with compaction

The previous observation is included in every perception call, so the model reports
deltas instead of re-describing a static scene — this is what makes event detection
work and keeps summaries informative. Memory is two-tier: the newest 24 observations
are kept verbatim in a deque; when it overflows, the oldest 12 are folded into a
≤150-word digest by a separate compaction call (`COMPACTION_SYSTEM`). This is the
same context-management move every long-running agent needs, in miniature. Watch the
"compactions" counter and the green digest box fill in after a couple of minutes.

### Pattern 04 — Adaptive attention (`next_interval_ms`)

The agent controls its own perception rate. High activity (≥7) drops the sampling
interval to 2.5s; a static scene backs off to 12s. The strip chart — the seismograph
trace in the UI — plots activity per sample so you can watch the agent lean in and
relax. This is the simplest possible policy on purpose; the interesting upgrades are
motion-pre-filtering frames client-side (skip the API call entirely when pixels
barely changed) and letting the model itself request its next interval in the
perception JSON.

### Pattern 05 — Event detection

The model flags discrete occurrences with a severity (info / notable / alert) inside
the perception schema. The backend dedupes identical labels within a 60-second window
so a person standing in frame doesn't produce thirty "person present" events. Severity
"alert" is reserved by prompt for safety-relevant or anomalous occurrences — the seam
where this becomes an OT/industrial monitoring tool.

### Pattern 06 — Grounded Q&A with cross-stack tool use

The chat endpoint builds a system prompt from the digest plus recent observations and
gives the model one tool: `capture_frame`. If the model decides memory isn't enough
("what's happening *right now*?"), it emits a tool_use block. The backend can't take
a photo — the browser owns the camera — so it parks the conversation in a pending
store and returns `needs_frame` to the frontend, which captures a frame and POSTs it
to `/api/ask/continue` as the tool_result. The dashed green message in the chat is
that round trip happening. This pattern — a tool whose execution lives on a different
machine than the agent loop — generalizes to robots, browsers, and any edge device.

## Things to try

Ask "what have you seen in the last few minutes?" (answers from memory, no tool call),
then "what am I holding right now?" (forces a capture_frame round trip). Wave your
arms and watch the sampling interval tighten on the strip chart. Let it run past ~24
frames and watch the first compaction land in the digest box.

## Where to take it next

The natural extensions, roughly in order of learning value: client-side motion
gating (frame differencing before any API call — the single biggest cost lever);
letting perception output its own requested interval and crop region (active
perception); persisting memory to SQLite so the agent survives restarts; multi-camera
fusion with one memory per feed and a cross-feed reasoner; and webhook/notification
actions on alert-severity events, which is the step that turns this from a learning
project into the skeleton of an industrial monitoring product.

## Cost note

At a 6s interval, an hour of watching is ~600 vision calls. Downscaling to 768px
keeps each around 1,000–1,500 input tokens, but leave it running and it adds up —
the motion-gating extension above is the fix worth building first.
