# CodeForge

An autonomous Python coding agent. You give it a task in plain English; it
**plans, writes multi-file projects, generates pytest tests, runs them, reads
the tracebacks, and fixes its own code until the tests pass** — narrating its
reasoning the whole way.

It's a real tool-use loop on top of the Anthropic Messages API: the model
drives, calling tools to write files and run commands in a sandboxed
workspace, and CodeForge feeds the results back until the job is done.

```
turn 1  ── plan + write files ──▶  write_file × N
turn 2  ── run the tests ───────▶  run_tests        → 2 failed
turn 3  ── read traceback, fix ─▶  write_file        → patch the bug
turn 4  ── run the tests ───────▶  run_tests        → all passed ✓
        ── final summary
```

## Install

```bash
cd codeforge
python -m venv .venv && source .venv/bin/activate
pip install -e .                 # or: pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...
```

Requires Python 3.10+.

## Use

One-shot:

```bash
codeforge "build a CLI todo app: add, list, and complete tasks, stored in JSON"
```

Interactive (context carries across tasks, so you can iterate):

```bash
codeforge
forge› write a function that parses ISO 8601 durations, with tests
forge› now add support for negative durations
forge› exit
```

Useful flags:

| flag | what it does |
|------|--------------|
| `--model claude-opus-4-8` | use the most capable model for hard tasks (default is the cheaper `claude-sonnet-4-6`) |
| `--workspace ./out` | where the agent reads/writes/runs (default `./workspace`) |
| `--confirm` | approve each shell command before it runs (default: auto-run) |
| `--max-iterations 60` | raise the turn cap for big jobs |
| `--timeout 300` | per-command timeout in seconds |

## How "very intelligent" actually works here

Intelligence in a coding agent is mostly the **feedback loop**, not the prompt.
CodeForge gets that loop right:

- **Execute & auto-debug** — it runs the code it writes, captures stdout/stderr
  and exit codes, and uses real tracebacks to fix real bugs instead of guessing.
- **Multi-file projects** — `write_file` / `read_file` / `list_files` let it
  build and navigate a whole package, not a single script.
- **Tests by default** — the system prompt requires pytest coverage, and
  `run_tests` is a first-class tool, so "done" means "green," not "looks right."
- **Visible reasoning** — model output is streamed live, so you watch it think,
  plan, and react to failures in real time.

## Architecture

```
codeforge/
  cli.py        # argparse + REPL
  agent.py      # the streaming tool-use loop, rich rendering, usage/cost
  tools.py      # tool JSON schemas + dispatcher
  workspace.py  # path-confined file ops + sandboxed command execution
  prompts.py    # the system prompt that defines agent behavior
  config.py     # settings + (rough) price table
tests/
  test_smoke.py # exercises workspace/tools with NO API call
```

Notes for the curious:
- The system prompt is sent with **prompt caching** to cut cost across the loop.
- Token usage (and a rough cost estimate, for priced models) prints after each task.
- Output from tools is truncated before going back to the model to keep the
  context lean.

## Safety

This agent **executes code and shell commands on your machine.** That's the
whole point, but treat it accordingly:

- File operations are confined to the workspace directory.
- An obvious-footgun blocklist refuses things like `sudo`, `rm -rf /`, fork
  bombs, and `dd`.
- Commands run with a timeout.
- Use `--confirm` to approve each command, **or** run inside a container / throwaway
  VM if you don't fully trust the task. Shell confinement is best-effort —
  a determined command can still reach outside the working directory.

## Test the agent itself

```bash
python -m pytest -q          # runs the no-API smoke tests
```

## Customizing

- Change behavior: edit `prompts.py`.
- Add a tool: add a schema to `TOOLS` in `tools.py` and a branch in
  `ToolDispatcher.execute`.
- Swap defaults: edit `config.py`.
